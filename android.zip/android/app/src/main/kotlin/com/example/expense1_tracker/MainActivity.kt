package com.example.expense1_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
